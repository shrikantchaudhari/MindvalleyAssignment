package com.mindvalley.app.data;

import com.mindvalley.app.data.remote.RemoteHelper;

public interface DataManager  extends RemoteHelper {
}
