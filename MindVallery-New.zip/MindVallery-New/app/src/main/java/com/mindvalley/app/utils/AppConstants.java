package com.mindvalley.app.utils;

public class AppConstants {

    public static final String API_URL = "http://pastebin.com/raw/wgkJgazE";
}
