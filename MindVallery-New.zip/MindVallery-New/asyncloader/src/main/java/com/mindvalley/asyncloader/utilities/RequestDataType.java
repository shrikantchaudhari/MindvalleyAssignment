package com.mindvalley.asyncloader.utilities;

public enum RequestDataType
{
	IMAGE,
	JSON
}
