package com.mindvalley.asyncloader.common;

public class Constants {

    public static final String REMOTE_DATA_SOURCE = "Remote";

    public static final String CACHE_DATA_SOURCE = "Cache";
}
